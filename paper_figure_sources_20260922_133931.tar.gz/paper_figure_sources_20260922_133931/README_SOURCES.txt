EventSleepFormer paper quantitative figure sources

Figure 2
--------
EventSleep1 five-seed class-wise results.

Proposed EventSleepFormer:
results/eventsleepformer_final_es1_v106/
configuration 577106a0cce2
seeds 13, 37, 73, 101, 137

ResNet-E:
results/eventsleepformer_v1/
resnet_e_published / paper_intended
seeds 13, 37, 73, 101, 137

Figure 3
--------
EventSleep2 five-seed frame-level and ground-truth-clip macro-F1.
Sources are the final summaries for:
- adapted EvS2-net
- reference EventSleepFormer
- proposed EventSleepFormer

Figure 4
--------
Proposed EventSleepFormer five-model ensemble diagnostics.
Sources are the ensemble frame-level confusion matrices and
per-class metrics from the final winner test.

No scientific result values should be hard-coded in the plotting
scripts; plotting code should read these archived source files.
